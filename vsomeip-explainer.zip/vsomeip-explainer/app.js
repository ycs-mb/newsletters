/**
 * vSOME/IP Protocol Explainer — Interactive Application Logic
 *
 * WHY: This script drives all interactivity for the single-page protocol
 * visualizer: particle canvas background, scroll-driven animations,
 * byte-level header dissection, command filtering, and message flow diagrams.
 */

// ═══════════════════════════════════════════
// PARTICLE NETWORK CANVAS
// ═══════════════════════════════════════════
(function initParticles() {
  const canvas = document.getElementById('particle-canvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');

  let particles = [];
  const PARTICLE_COUNT = 60;
  const MAX_DIST = 150;

  function resize() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
  }
  resize();
  window.addEventListener('resize', resize);

  class Particle {
    constructor() {
      this.x = Math.random() * canvas.width;
      this.y = Math.random() * canvas.height;
      this.vx = (Math.random() - 0.5) * 0.4;
      this.vy = (Math.random() - 0.5) * 0.4;
      this.radius = Math.random() * 2 + 0.5;
    }
    update() {
      this.x += this.vx;
      this.y += this.vy;
      if (this.x < 0 || this.x > canvas.width) this.vx *= -1;
      if (this.y < 0 || this.y > canvas.height) this.vy *= -1;
    }
    draw() {
      ctx.beginPath();
      ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(0,194,255,0.5)';
      ctx.fill();
    }
  }

  for (let i = 0; i < PARTICLE_COUNT; i++) {
    particles.push(new Particle());
  }

  function animate() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    for (let i = 0; i < particles.length; i++) {
      particles[i].update();
      particles[i].draw();
      for (let j = i + 1; j < particles.length; j++) {
        const dx = particles[i].x - particles[j].x;
        const dy = particles[i].y - particles[j].y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < MAX_DIST) {
          ctx.beginPath();
          ctx.moveTo(particles[i].x, particles[i].y);
          ctx.lineTo(particles[j].x, particles[j].y);
          ctx.strokeStyle = `rgba(0,194,255,${0.15 * (1 - dist / MAX_DIST)})`;
          ctx.lineWidth = 0.5;
          ctx.stroke();
        }
      }
    }
    requestAnimationFrame(animate);
  }
  animate();
})();

// ═══════════════════════════════════════════
// SCROLL-DRIVEN ANIMATIONS (IntersectionObserver)
// ═══════════════════════════════════════════
(function initScrollAnimations() {
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
        }
      });
    },
    { threshold: 0.15 }
  );

  document.querySelectorAll('.animate-in').forEach((el) => observer.observe(el));
})();

// ═══════════════════════════════════════════
// NAVIGATION SIDEBAR
// ═══════════════════════════════════════════
(function initNav() {
  const dots = document.querySelectorAll('.nav-dot');
  const sections = [
    'hero', 'osi', 'header', 'serialization', 'sd', 'transport', 'protocol', 'flow', 'architecture'
  ];

  // Click handlers
  dots.forEach((dot) => {
    dot.addEventListener('click', () => {
      const id = dot.getAttribute('data-section');
      document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
    });
  });

  // Scroll spy
  const sectionObserver = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const id = entry.target.id;
          dots.forEach((d) => d.classList.remove('active'));
          const activeDot = document.querySelector(`.nav-dot[data-section="${id}"]`);
          if (activeDot) activeDot.classList.add('active');
        }
      });
    },
    { threshold: 0.3 }
  );

  sections.forEach((id) => {
    const el = document.getElementById(id);
    if (el) sectionObserver.observe(el);
  });
})();

// ═══════════════════════════════════════════
// OSI LAYER TOGGLE
// ═══════════════════════════════════════════
(function initOSI() {
  const layers = document.querySelectorAll('.osi-layer');
  layers.forEach((layer) => {
    layer.addEventListener('click', () => {
      const wasActive = layer.classList.contains('active');
      layers.forEach((l) => l.classList.remove('active'));
      if (!wasActive) layer.classList.add('active');
    });
  });
})();

// ═══════════════════════════════════════════
// SOME/IP HEADER DISSECTOR
// ═══════════════════════════════════════════
(function initHeaderDissector() {
  const grid = document.getElementById('byte-grid');
  const legend = document.getElementById('field-legend');
  const tooltip = document.getElementById('header-tooltip');
  if (!grid || !legend || !tooltip) return;

  // Field definitions: name, byte range [start, end], color, example hex, description
  const fields = [
    {
      name: 'Service ID',
      start: 0, end: 1,
      color: 'rgba(0,194,255,0.25)',
      colorSolid: '#00c2ff',
      hex: ['12', '34'],
      desc: 'Identifies the service. Range 0x0000–0xFFFE for normal services. 0xFFFF is reserved for Service Discovery (SD).',
      detail: '2 bytes · Big-endian · uint16'
    },
    {
      name: 'Method / Event ID',
      start: 2, end: 3,
      color: 'rgba(124,77,255,0.25)',
      colorSolid: '#7c4dff',
      hex: ['80', 'E8'],
      desc: 'Identifies the method or event. Bit 15 = 1 indicates an event/notification (0x8000+). Methods use 0x0001–0x7FFF.',
      detail: '2 bytes · Big-endian · uint16 · Bit 15 → Event flag'
    },
    {
      name: 'Length',
      start: 4, end: 7,
      color: 'rgba(255,180,0,0.25)',
      colorSolid: '#ffb400',
      hex: ['00', '00', '00', '15'],
      desc: 'Total length in bytes from Client ID to end of payload (i.e., remaining bytes after this field). Minimum 8 (header part 2 only, no payload).',
      detail: '4 bytes · Big-endian · uint32'
    },
    {
      name: 'Client ID',
      start: 8, end: 9,
      color: 'rgba(0,230,118,0.25)',
      colorSolid: '#00e676',
      hex: ['13', '43'],
      desc: 'Unique identifier for the calling client. High byte = diagnosis address, low byte = client enumeration. Assigned by Routing Manager.',
      detail: '2 bytes · Big-endian · uint16'
    },
    {
      name: 'Session ID',
      start: 10, end: 11,
      color: 'rgba(224,64,251,0.25)',
      colorSolid: '#e040fb',
      hex: ['00', '03'],
      desc: 'Per-client monotonically-increasing counter. Identifies individual calls within a session. Wraps around from 0xFFFF to 0x0001.',
      detail: '2 bytes · Big-endian · uint16'
    },
    {
      name: 'Protocol Version',
      start: 12, end: 12,
      color: 'rgba(29,233,182,0.25)',
      colorSolid: '#1de9b6',
      hex: ['01'],
      desc: 'SOME/IP protocol version. Currently always 0x01.',
      detail: '1 byte · uint8 · Always 0x01'
    },
    {
      name: 'Interface Version',
      start: 13, end: 13,
      color: 'rgba(255,109,0,0.25)',
      colorSolid: '#ff6d00',
      hex: ['00'],
      desc: 'Major version of the service interface. Used to ensure wire-compatibility between client and server.',
      detail: '1 byte · uint8 · Major version'
    },
    {
      name: 'Message Type',
      start: 14, end: 14,
      color: 'rgba(255,82,82,0.25)',
      colorSolid: '#ff5252',
      hex: ['00'],
      desc: 'REQUEST=0x00, REQUEST_NO_RETURN=0x01, NOTIFICATION=0x02, RESPONSE=0x80, ERROR=0x81. ACK variants add 0x40.',
      detail: '1 byte · uint8 · message_type_e enum'
    },
    {
      name: 'Return Code',
      start: 15, end: 15,
      color: 'rgba(158,158,158,0.3)',
      colorSolid: '#9e9e9e',
      hex: ['00'],
      desc: `AUTOSAR [PRS_SOMEIP_00191] Codes:<br>
      <table class="rc-table">
        <tr><td>0x00</td><td>E_OK</td><td>0x05</td><td>E_NOT_REACHABLE</td></tr>
        <tr><td>0x01</td><td>E_NOT_OK</td><td>0x06</td><td>E_TIMEOUT</td></tr>
        <tr><td>0x02</td><td>E_UNKNOWN_SERVICE</td><td>0x07</td><td>E_WRONG_PROTOCOL_VERSION</td></tr>
        <tr><td>0x03</td><td>E_UNKNOWN_METHOD</td><td>0x08</td><td>E_WRONG_INTERFACE_VERSION</td></tr>
        <tr><td>0x04</td><td>E_NOT_READY</td><td>0x09</td><td>E_MALFORMED_MESSAGE</td></tr>
        <tr><td>0x0A</td><td>E_WRONG_MESSAGE_TYPE</td><td>0x0B+</td><td>E2E & Security Errors</td></tr>
      </table>`,
      detail: '1 byte · uint8 · return_code_e enum'
    },
  ];

  // Render byte grid
  for (let i = 0; i < 16; i++) {
    const cell = document.createElement('div');
    cell.className = 'byte-cell';
    cell.setAttribute('data-byte', i);

    // Find which field this byte belongs to
    const field = fields.find(f => i >= f.start && i <= f.end);
    if (field) {
      cell.style.setProperty('--field-color', field.color);
      cell.style.background = field.color;
      cell.textContent = field.hex[i - field.start];
      cell.setAttribute('data-field', field.name);
    }

    cell.addEventListener('mouseenter', () => highlightField(field?.name));
    cell.addEventListener('click', () => highlightField(field?.name));
    grid.appendChild(cell);
  }

  // Render legend
  fields.forEach((field) => {
    const item = document.createElement('div');
    item.className = 'field-item';
    item.setAttribute('data-field', field.name);
    item.innerHTML = `
      <div class="field-swatch" style="background: ${field.colorSolid}"></div>
      <div class="field-info">
        <h4>${field.name}</h4>
        <p>Bytes ${field.start}–${field.end} · ${field.detail}</p>
      </div>
    `;
    item.addEventListener('click', () => highlightField(field.name));
    item.addEventListener('mouseenter', () => highlightField(field.name));
    legend.appendChild(item);
  });

  function highlightField(fieldName) {
    if (!fieldName) return;

    // Remove existing highlights
    grid.querySelectorAll('.byte-cell').forEach(c => c.classList.remove('highlight'));
    legend.querySelectorAll('.field-item').forEach(i => i.classList.remove('active'));

    // Add highlights
    grid.querySelectorAll(`.byte-cell[data-field="${fieldName}"]`).forEach(c => c.classList.add('highlight'));
    legend.querySelector(`.field-item[data-field="${fieldName}"]`)?.classList.add('active');

    // Update tooltip
    const field = fields.find(f => f.name === fieldName);
    if (field && tooltip) {
      tooltip.innerHTML = `
        <h3>${field.name} <code>Byte${field.start === field.end ? ' ' + field.start : 's ' + field.start + '–' + field.end}</code></h3>
        <p>${field.desc}</p>
        <p style="margin-top:8px; font-size: 0.78rem; color: var(--text-dim);">${field.detail}</p>
      `;
    }
  }
})();

// ═══════════════════════════════════════════
// MAGIC COOKIES
// ═══════════════════════════════════════════
(function initMagicCookies() {
  const clientCookieBytes = [
    { val: 'FF', group: 'service' },
    { val: 'FF', group: 'service' },
    { val: '00', group: 'method' },
    { val: '00', group: 'method' },
    { val: '00', group: 'length' },
    { val: '00', group: 'length' },
    { val: '00', group: 'length' },
    { val: '08', group: 'length' },
    { val: 'DE', group: 'magic' },
    { val: 'AD', group: 'magic' },
    { val: 'BE', group: 'magic' },
    { val: 'EF', group: 'magic' },
    { val: '01', group: 'proto' },
    { val: '01', group: 'iface' },
    { val: '01', group: 'type' },
    { val: '00', group: 'code' },
  ];

  const serviceCookieBytes = [
    { val: 'FF', group: 'service' },
    { val: 'FF', group: 'service' },
    { val: '80', group: 'method' },
    { val: '00', group: 'method' },
    { val: '00', group: 'length' },
    { val: '00', group: 'length' },
    { val: '00', group: 'length' },
    { val: '08', group: 'length' },
    { val: 'DE', group: 'magic' },
    { val: 'AD', group: 'magic' },
    { val: 'BE', group: 'magic' },
    { val: 'EF', group: 'magic' },
    { val: '01', group: 'proto' },
    { val: '01', group: 'iface' },
    { val: '02', group: 'type' },
    { val: '00', group: 'code' },
  ];

  const groupColors = {
    service: 'bg-cyan',
    method: 'bg-purple',
    length: 'bg-amber',
    magic: 'bg-red',
    proto: 'bg-teal',
    iface: 'bg-orange',
    type: 'bg-magenta',
    code: 'bg-green',
  };

  const groupTextColors = {
    service: 'text-cyan',
    method: 'text-purple',
    length: 'text-amber',
    magic: 'text-red',
    proto: 'text-teal',
    iface: 'text-orange',
    type: 'text-magenta',
    code: 'text-green',
  };

  function renderCookieBytes(containerId, bytes) {
    const container = document.getElementById(containerId);
    if (!container) return;
    bytes.forEach((b) => {
      const el = document.createElement('div');
      el.className = `cookie-byte ${groupColors[b.group]} ${groupTextColors[b.group]}`;
      el.textContent = b.val;
      el.title = b.group;
      container.appendChild(el);
    });
  }

  renderCookieBytes('client-cookie', clientCookieBytes);
  renderCookieBytes('service-cookie', serviceCookieBytes);
})();

// ═══════════════════════════════════════════
// INTERNAL PROTOCOL COMMANDS
// ═══════════════════════════════════════════
(function initCommands() {
  const commands = [
    { hex: '0x00', name: 'ASSIGN_CLIENT', cat: 'lifecycle', desc: 'Request client ID assignment from routing manager. Payload contains application name.' },
    { hex: '0x01', name: 'ASSIGN_CLIENT_ACK', cat: 'lifecycle', desc: 'Routing manager responds with the assigned client ID (2 bytes).' },
    { hex: '0x02', name: 'REGISTER_APPLICATION', cat: 'lifecycle', desc: 'Application registers itself with the routing manager. Includes local port.' },
    { hex: '0x03', name: 'DEREGISTER_APPLICATION', cat: 'lifecycle', desc: 'Application deregisters from the routing manager. No payload.' },
    { hex: '0x05', name: 'ROUTING_INFO', cat: 'lifecycle', desc: 'Routing manager broadcasts routing table updates (add/remove clients and service instances).' },
    { hex: '0x06', name: 'REGISTERED_ACK', cat: 'lifecycle', desc: 'Client acknowledges successful registration.' },
    { hex: '0x07', name: 'PING', cat: 'lifecycle', desc: 'Routing manager sends keepalive ping to check client liveness.' },
    { hex: '0x08', name: 'PONG', cat: 'lifecycle', desc: 'Client responds to ping with pong, confirming it is alive.' },

    { hex: '0x10', name: 'OFFER_SERVICE', cat: 'service', desc: 'Application offers a service (Service ID, Instance ID, Major, Minor version).' },
    { hex: '0x11', name: 'STOP_OFFER_SERVICE', cat: 'service', desc: 'Application stops offering a previously offered service.' },
    { hex: '0x14', name: 'REQUEST_SERVICE', cat: 'service', desc: 'Client requests availability of one or more services.' },
    { hex: '0x15', name: 'RELEASE_SERVICE', cat: 'service', desc: 'Client releases a previously requested service.' },
    { hex: '0x1F', name: 'OFFERED_SERVICES_REQ', cat: 'service', desc: 'Query for currently offered services (LOCAL, REMOTE, or ALL).' },
    { hex: '0x20', name: 'OFFERED_SERVICES_RESP', cat: 'service', desc: 'Response with list of currently offered service instances.' },

    { hex: '0x12', name: 'SUBSCRIBE', cat: 'subscription', desc: 'Subscribe to an eventgroup with filter criteria (on-change, interval).' },
    { hex: '0x13', name: 'UNSUBSCRIBE', cat: 'subscription', desc: 'Unsubscribe from an eventgroup.' },
    { hex: '0x16', name: 'SUBSCRIBE_NACK', cat: 'subscription', desc: 'Subscription rejected by the service provider.' },
    { hex: '0x17', name: 'SUBSCRIBE_ACK', cat: 'subscription', desc: 'Subscription accepted by the service provider.' },
    { hex: '0x21', name: 'UNSUBSCRIBE_ACK', cat: 'subscription', desc: 'Unsubscription acknowledged.' },
    { hex: '0x2A', name: 'EXPIRE', cat: 'subscription', desc: 'Subscription has expired (TTL elapsed).' },
    { hex: '0x1B', name: 'REGISTER_EVENT', cat: 'subscription', desc: 'Register an event/field with its type, reliability, and eventgroups.' },
    { hex: '0x1C', name: 'UNREGISTER_EVENT', cat: 'subscription', desc: 'Unregister a previously registered event.' },
    { hex: '0x22', name: 'RESEND_PROVIDED_EVENTS', cat: 'subscription', desc: 'Request resending of initial event values after offer.' },

    { hex: '0x18', name: 'SEND', cat: 'messaging', desc: 'Forward a SOME/IP message through the routing manager. Contains full SOME/IP payload.' },
    { hex: '0x19', name: 'NOTIFY', cat: 'messaging', desc: 'Route a notification/event to all subscribers.' },
    { hex: '0x1A', name: 'NOTIFY_ONE', cat: 'messaging', desc: 'Route a selective notification to a specific subscriber (unicast).' },

    { hex: '0x23', name: 'UPDATE_SECURITY_POLICY', cat: 'security', desc: 'Update security policy with UID/GID credentials.' },
    { hex: '0x24', name: 'UPDATE_SEC_POLICY_RESP', cat: 'security', desc: 'Response to security policy update request.' },
    { hex: '0x25', name: 'REMOVE_SECURITY_POLICY', cat: 'security', desc: 'Remove a security policy by UID/GID.' },
    { hex: '0x26', name: 'REMOVE_SEC_POLICY_RESP', cat: 'security', desc: 'Response to security policy removal.' },
    { hex: '0x27', name: 'UPDATE_SEC_CREDENTIALS', cat: 'security', desc: 'Update security credentials (UID + GID pairs).' },
    { hex: '0x28', name: 'DISTRIBUTE_SEC_POLICIES', cat: 'security', desc: 'Distribute multiple security policies in batch.' },
    { hex: '0x29', name: 'UPDATE_SEC_POLICY_INT', cat: 'security', desc: 'Internal security policy update (same format as 0x23).' },

    { hex: '0x30', name: 'SUSPEND', cat: 'system', desc: 'Suspend the routing manager. Used during system sleep/hibernate.' },
    { hex: '0x31', name: 'CONFIG', cat: 'system', desc: 'Send key-value configuration pairs to an application at runtime.' },
  ];

  const grid = document.getElementById('cmd-grid');
  const catBtns = document.querySelectorAll('.cmd-cat-btn');
  if (!grid) return;

  function renderCommands(filter) {
    grid.innerHTML = '';
    const filtered = filter === 'all' ? commands : commands.filter(c => c.cat === filter);
    filtered.forEach((cmd) => {
      const card = document.createElement('div');
      card.className = 'cmd-card';
      card.setAttribute('data-cat', cmd.cat);
      card.innerHTML = `
        <span class="cmd-hex">${cmd.hex}</span>
        <div class="cmd-info">
          <h4>${cmd.name}</h4>
          <p>${cmd.desc}</p>
        </div>
      `;
      grid.appendChild(card);
    });
  }

  renderCommands('all');

  catBtns.forEach((btn) => {
    btn.addEventListener('click', () => {
      catBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      renderCommands(btn.getAttribute('data-cat'));
    });
  });

  // Command header visual
  const hdrContainer = document.getElementById('cmd-header-bytes');
  if (!hdrContainer) return;

  const hdrFields = [
    { offset: '0x00', val: 'CMD', lbl: 'Command', color: 'var(--cyan)' },
    { offset: '0x01', val: 'VER', lbl: 'Version (H)', color: 'var(--purple)' },
    { offset: '0x02', val: 'VER', lbl: 'Version (L)', color: 'var(--purple)' },
    { offset: '0x03', val: 'CLI', lbl: 'Client (H)', color: 'var(--green)' },
    { offset: '0x04', val: 'CLI', lbl: 'Client (L)', color: 'var(--green)' },
    { offset: '0x05', val: 'SIZ', lbl: 'Size [3]', color: 'var(--amber)' },
    { offset: '0x06', val: 'SIZ', lbl: 'Size [2]', color: 'var(--amber)' },
    { offset: '0x07', val: 'SIZ', lbl: 'Size [1]', color: 'var(--amber)' },
    { offset: '0x08', val: 'SIZ', lbl: 'Size [0]', color: 'var(--amber)' },
  ];

  hdrFields.forEach((f) => {
    const cell = document.createElement('div');
    cell.className = 'cmd-hdr-cell';
    cell.style.background = f.color.replace(')', ',0.12)').replace('var(', 'rgba(');
    cell.style.background = `color-mix(in srgb, ${f.color} 12%, transparent)`;
    cell.style.color = f.color;
    cell.innerHTML = `
      <span class="offset">${f.offset}</span>
      <span class="val">${f.val}</span>
      <span class="lbl">${f.lbl}</span>
    `;
    hdrContainer.appendChild(cell);
  });
})();

// ═══════════════════════════════════════════
// MESSAGE FLOWS
// ═══════════════════════════════════════════
(function initFlows() {
  const tabs = document.querySelectorAll('.flow-tab');
  const diagram = document.getElementById('flow-diagram');
  if (!diagram) return;

  const flows = {
    'request-response': {
      title: 'Request / Response (RPC Call)',
      participants: ['Client App', 'Routing Manager', 'Service App'],
      steps: [
        { from: 'client', to: 'routing', arrow: '→', name: 'REGISTER_APPLICATION (0x02)', desc: 'Client registers with routing manager' },
        { from: 'routing', to: 'client', arrow: '←', name: 'ROUTING_INFO (0x05)', desc: 'Routing manager confirms registration' },
        { from: 'client', to: 'routing', arrow: '→', name: 'REQUEST_SERVICE (0x14)', desc: 'Client requests service [0x1234]' },
        { from: 'routing', to: 'client', arrow: '←', name: 'ROUTING_INFO (0x05)', desc: 'Service is available — route info sent' },
        { from: 'client', to: 'service', arrow: '→→', name: 'SEND (0x18) → MT_REQUEST', desc: 'SOME/IP Request message routed to service', highlight: true },
        { from: 'service', to: 'client', arrow: '←←', name: 'SEND (0x18) → MT_RESPONSE', desc: 'SOME/IP Response message routed back', highlight: true },
      ]
    },
    'publish-subscribe': {
      title: 'Publish / Subscribe (Event Notification)',
      participants: ['Subscriber', 'Routing Manager', 'Publisher'],
      steps: [
        { from: 'service', to: 'routing', arrow: '→', name: 'OFFER_SERVICE (0x10)', desc: 'Publisher offers service with eventgroups' },
        { from: 'service', to: 'routing', arrow: '→', name: 'REGISTER_EVENT (0x1B)', desc: 'Publisher registers events for eventgroup' },
        { from: 'client', to: 'routing', arrow: '→', name: 'REQUEST_SERVICE (0x14)', desc: 'Subscriber requests service' },
        { from: 'client', to: 'routing', arrow: '→', name: 'SUBSCRIBE (0x12)', desc: 'Subscriber subscribes to eventgroup' },
        { from: 'routing', to: 'service', arrow: '→', name: 'SUBSCRIBE (0x12)', desc: 'Routing forwards subscription to publisher' },
        { from: 'routing', to: 'client', arrow: '←', name: 'SUBSCRIBE_ACK (0x17)', desc: 'Subscription accepted' },
        { from: 'service', to: 'client', arrow: '←←', name: 'NOTIFY (0x19)', desc: 'Event notification sent to subscriber', highlight: true },
        { from: 'service', to: 'client', arrow: '←←', name: 'NOTIFY (0x19)', desc: 'Another event notification (cyclic or on-change)', highlight: true },
      ]
    },
    'service-discovery': {
      title: 'SOME/IP Service Discovery Flow',
      participants: ['Client ECU', 'Network (Multicast)', 'Server ECU'],
      steps: [
        { from: 'service', to: 'routing', arrow: '→', name: 'SD OfferService (0x01)', desc: 'Server multicasts OfferService entry via UDP 224.0.0.x:30490', highlight: true },
        { from: 'client', to: 'routing', arrow: '→', name: 'SD FindService (0x00)', desc: 'Client multicasts FindService query (optional)', },
        { from: 'service', to: 'routing', arrow: '→', name: 'SD OfferService (0x01)', desc: 'Server responds with OfferService + IPv4Endpoint option', highlight: true },
        { from: 'client', to: 'service', arrow: '→→', name: 'SD Subscribe (0x06)', desc: 'Client sends SubscribeEventgroup via unicast UDP' },
        { from: 'service', to: 'client', arrow: '←←', name: 'SD SubscribeAck (0x07)', desc: 'Server acknowledges subscription via unicast' },
        { from: 'service', to: 'client', arrow: '←←', name: 'Initial Event (Notification)', desc: 'Server sends initial field values to new subscriber' },
        { from: 'service', to: 'routing', arrow: '→', name: 'SD StopOffer (TTL=0)', desc: 'Server stops offering service (TTL=0 in OfferService)' },
      ]
    },
  };

  function renderFlow(flowId) {
    const flow = flows[flowId];
    if (!flow) return;

    let html = `
      <div style="text-align: center; margin-bottom: 32px;">
        <h3 style="font-size: 1.15rem; font-weight: 700; color: var(--text-primary);">${flow.title}</h3>
      </div>
      <div class="flow-participants">
        <div class="flow-participant client"><div class="name">${flow.participants[0]}</div></div>
        <div class="flow-participant routing"><div class="name">${flow.participants[1]}</div></div>
        <div class="flow-participant service"><div class="name">${flow.participants[2]}</div></div>
      </div>
      <div style="padding: 16px 0;">
    `;

    flow.steps.forEach((step, i) => {
      const fromClass = step.from === 'client' ? 'from-client' : step.from === 'routing' ? 'from-routing' : 'from-service';
      const arrowClass = step.arrow.includes('←') ? 'left' : 'right';
      const highlightStyle = step.highlight ? 'border-color: var(--cyan); background: rgba(0,194,255,0.04);' : '';

      html += `
        <div class="flow-step" data-step="${i}" style="transition-delay: ${i * 0.1}s;">
          <div class="flow-step-num">${i + 1}</div>
          <div class="flow-step-line" style="${highlightStyle}">
            <span class="flow-step-arrow ${arrowClass}">${step.arrow}</span>
            <div class="flow-step-content">
              <div class="msg-name">${step.name}</div>
              <div class="msg-desc">${step.desc}</div>
            </div>
            <span class="msg-from ${fromClass}">${step.from}</span>
          </div>
        </div>
      `;
    });

    html += '</div>';
    diagram.innerHTML = html;

    // Animate steps
    requestAnimationFrame(() => {
      const steps = diagram.querySelectorAll('.flow-step');
      steps.forEach((step, i) => {
        setTimeout(() => step.classList.add('visible'), i * 150);
      });
    });
  }

  // Tab handlers
  tabs.forEach((tab) => {
    tab.addEventListener('click', () => {
      tabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      renderFlow(tab.getAttribute('data-flow'));
    });
  });

  // Initial render
  renderFlow('request-response');
})();

// ═══════════════════════════════════════════
// SD ENTRY INTERACTIVE
// ═══════════════════════════════════════════
(function initSD() {
  const entries = document.querySelectorAll('#sd-entries .sd-entry');
  entries.forEach((entry) => {
    entry.addEventListener('click', () => {
      entries.forEach(e => e.classList.remove('active'));
      entry.classList.add('active');
    });
  });
})();
